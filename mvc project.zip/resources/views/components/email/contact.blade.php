<h3>You have contact request</h3>
<table>
  <tr>
    <th>Name</th>
    <td>{{ $name }}</td>
  </tr>
  <tr>
    <th>Email</th>
    <td>{{ $email }}</td>
  </tr>
</table>

<div>
  {{$body}}
</div>